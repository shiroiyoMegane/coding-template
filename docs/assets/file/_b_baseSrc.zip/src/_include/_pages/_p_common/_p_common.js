const globalSet = require('../../_modules/_m_javascript/_m_globalSet/_m_globalSet.js');
globalSet();
let _g = window.GLOBAL;

function init() {
}

module.exports = () => {
	init();
}