'use strict'
const comSet = require('../../_include/_pages/_p_common/_p_common.js');
function init() {
	comSet();
}
init();